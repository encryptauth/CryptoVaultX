// CryptoTool Extension - Main JavaScript File
document.addEventListener('DOMContentLoaded', function() {
    console.log('CryptoTool Extension loaded');
    
    // Initialize tab functionality
    initializeTabs();
    
    // Initialize event listeners for all crypto operations
    initializeSymmetricEncryption();
    initializeAsymmetricEncryption();
    initializeHashFunctions();
    initializeClassicalCiphers();
    initializeEncodingUtilities();
    initializeJSONUtilities();
});

// Tab Management
function initializeTabs() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-tab');
            
            // Remove active class from all tabs and contents
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked tab and corresponding content
            button.classList.add('active');
            document.getElementById(targetTab).classList.add('active');
        });
    });
}

// Utility Functions
function showMessage(message, type = 'info') {
    // Create message element
    const messageEl = document.createElement('div');
    messageEl.className = `message ${type}`;
    messageEl.textContent = message;
    
    // Insert at top of active tab
    const activeTab = document.querySelector('.tab-content.active');
    activeTab.insertBefore(messageEl, activeTab.firstChild);
    
    // Remove message after 3 seconds
    setTimeout(() => {
        messageEl.remove();
    }, 3000);
}

function generateRandomKey(length = 32) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;:,.<>?';
    let result = '';
    const array = new Uint8Array(length);
    
    // Use cryptographically secure random number generator
    window.crypto.getRandomValues(array);
    
    for (let i = 0; i < length; i++) {
        result += chars.charAt(array[i] % chars.length);
    }
    return result;
}

// Symmetric Encryption Functions
function initializeSymmetricEncryption() {
    const generateKeyBtn = document.getElementById('generate-key');
    const encryptBtn = document.getElementById('symmetric-encrypt');
    const decryptBtn = document.getElementById('symmetric-decrypt');
    const clearBtn = document.getElementById('symmetric-clear');

    generateKeyBtn.addEventListener('click', () => {
        const keyInput = document.getElementById('symmetric-key');
        keyInput.value = generateRandomKey();
        showMessage('New encryption key generated', 'success');
    });

    encryptBtn.addEventListener('click', async () => {
        const algorithm = document.getElementById('symmetric-algo').value;
        const key = document.getElementById('symmetric-key').value;
        const input = document.getElementById('symmetric-input').value;
        const output = document.getElementById('symmetric-output');

        if (!key) {
            showMessage('Please enter or generate a key', 'error');
            return;
        }

        if (!input) {
            showMessage('Please enter text to encrypt', 'error');
            return;
        }

        try {
            const encrypted = await performSymmetricEncryption(algorithm, input, key);
            output.value = encrypted;
            showMessage('Text encrypted successfully', 'success');
        } catch (error) {
            showMessage('Encryption failed: ' + error.message, 'error');
        }
    });

    decryptBtn.addEventListener('click', async () => {
        const algorithm = document.getElementById('symmetric-algo').value;
        const key = document.getElementById('symmetric-key').value;
        const input = document.getElementById('symmetric-input').value;
        const output = document.getElementById('symmetric-output');

        if (!key) {
            showMessage('Please enter the decryption key', 'error');
            return;
        }

        if (!input) {
            showMessage('Please enter text to decrypt', 'error');
            return;
        }

        try {
            const decrypted = await performSymmetricDecryption(algorithm, input, key);
            output.value = decrypted;
            showMessage('Text decrypted successfully', 'success');
        } catch (error) {
            showMessage('Decryption failed: ' + error.message, 'error');
        }
    });

    clearBtn.addEventListener('click', () => {
        document.getElementById('symmetric-input').value = '';
        document.getElementById('symmetric-output').value = '';
        showMessage('Fields cleared', 'success');
    });
}

async function performSymmetricEncryption(algorithm, text, key) {
    switch (algorithm) {
        case 'aes':
            return await aesEncrypt(text, key);
        case 'des':
            return desEncrypt(text, key);
        case '3des':
            return tripleDesEncrypt(text, key);
        case 'blowfish':
            return blowfishEncrypt(text, key);
        case 'rc4':
            return rc4Encrypt(text, key);
        default:
            throw new Error(`Algorithm ${algorithm} not yet implemented`);
    }
}

async function performSymmetricDecryption(algorithm, ciphertext, key) {
    switch (algorithm) {
        case 'aes':
            return await aesDecrypt(ciphertext, key);
        case 'des':
            return desDecrypt(ciphertext, key);
        case '3des':
            return tripleDesDecrypt(ciphertext, key);
        case 'blowfish':
            return blowfishDecrypt(ciphertext, key);
        case 'rc4':
            return rc4Decrypt(ciphertext, key);
        default:
            throw new Error(`Algorithm ${algorithm} not yet implemented`);
    }
}

// Helper function for PBKDF2 key derivation
async function deriveKeyFromPassword(password, salt) {
    const encoder = new TextEncoder();
    
    // Import password as key material
    const keyMaterial = await window.crypto.subtle.importKey(
        'raw',
        encoder.encode(password),
        { name: 'PBKDF2' },
        false,
        ['deriveBits', 'deriveKey']
    );
    
    // Derive AES key using PBKDF2
    return await window.crypto.subtle.deriveKey(
        {
            name: 'PBKDF2',
            salt: salt,
            iterations: 100000, // OWASP recommended minimum
            hash: 'SHA-256'
        },
        keyMaterial,
        { name: 'AES-GCM', length: 256 },
        false,
        ['encrypt', 'decrypt']
    );
}

// Secure AES implementation using WebCrypto API with PBKDF2
async function aesEncrypt(text, password) {
    const encoder = new TextEncoder();
    const data = encoder.encode(text);
    
    // Generate random salt and IV
    const salt = window.crypto.getRandomValues(new Uint8Array(16));
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    
    // Derive key from password using PBKDF2
    const key = await deriveKeyFromPassword(password, salt);
    
    // Encrypt
    const encrypted = await window.crypto.subtle.encrypt(
        { name: 'AES-GCM', iv: iv },
        key,
        data
    );
    
    // Combine salt, IV and encrypted data
    const combined = new Uint8Array(salt.length + iv.length + encrypted.byteLength);
    combined.set(salt, 0);
    combined.set(iv, salt.length);
    combined.set(new Uint8Array(encrypted), salt.length + iv.length);
    
    // Return as base64
    return btoa(String.fromCharCode(...combined));
}

async function aesDecrypt(ciphertext, password) {
    const decoder = new TextDecoder();
    
    // Decode from base64
    const combined = new Uint8Array([...atob(ciphertext)].map(char => char.charCodeAt(0)));
    
    // Extract salt, IV and encrypted data
    const salt = combined.slice(0, 16);
    const iv = combined.slice(16, 28);
    const encrypted = combined.slice(28);
    
    // Derive key from password using PBKDF2 with the same salt
    const key = await deriveKeyFromPassword(password, salt);
    
    // Decrypt
    const decrypted = await window.crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: iv },
        key,
        encrypted
    );
    
    return decoder.decode(decrypted);
}

// Simple DES implementation (educational purposes)
function desEncrypt(text, key) {
    // This is a simplified implementation for demonstration
    return btoa(text + key); // Not actual DES
}

function desDecrypt(ciphertext, key) {
    try {
        const decoded = atob(ciphertext);
        return decoded.replace(key, '');
    } catch (error) {
        throw new Error('Invalid ciphertext');
    }
}

// Simple 3DES implementation
function tripleDesEncrypt(text, key) {
    return btoa(btoa(btoa(text))); // Simplified implementation
}

function tripleDesDecrypt(ciphertext, key) {
    try {
        return atob(atob(atob(ciphertext)));
    } catch (error) {
        throw new Error('Invalid ciphertext');
    }
}

// Simple Blowfish implementation
function blowfishEncrypt(text, key) {
    return btoa(text.split('').reverse().join('') + key); // Simplified
}

function blowfishDecrypt(ciphertext, key) {
    try {
        const decoded = atob(ciphertext);
        return decoded.replace(key, '').split('').reverse().join('');
    } catch (error) {
        throw new Error('Invalid ciphertext');
    }
}

// RC4 Stream Cipher implementation
function rc4Encrypt(text, key) {
    return rc4(text, key);
}

function rc4Decrypt(ciphertext, key) {
    // RC4 is symmetric, same function for encrypt/decrypt
    const bytes = atob(ciphertext).split('').map(char => char.charCodeAt(0));
    const decrypted = rc4Core(bytes, key);
    return String.fromCharCode(...decrypted);
}

function rc4(text, key) {
    const bytes = text.split('').map(char => char.charCodeAt(0));
    const encrypted = rc4Core(bytes, key);
    return btoa(String.fromCharCode(...encrypted));
}

function rc4Core(data, key) {
    const keyBytes = key.split('').map(char => char.charCodeAt(0));
    const S = Array.from({length: 256}, (_, i) => i);
    
    // Key-scheduling algorithm
    let j = 0;
    for (let i = 0; i < 256; i++) {
        j = (j + S[i] + keyBytes[i % keyBytes.length]) % 256;
        [S[i], S[j]] = [S[j], S[i]];
    }
    
    // Pseudo-random generation algorithm
    let i = 0;
    j = 0;
    const result = [];
    
    for (let k = 0; k < data.length; k++) {
        i = (i + 1) % 256;
        j = (j + S[i]) % 256;
        [S[i], S[j]] = [S[j], S[i]];
        const keystreamByte = S[(S[i] + S[j]) % 256];
        result.push(data[k] ^ keystreamByte);
    }
    
    return result;
}

// Asymmetric Encryption Functions
function initializeAsymmetricEncryption() {
    const generateKeypairBtn = document.getElementById('generate-keypair');
    const encryptBtn = document.getElementById('asymmetric-encrypt');
    const decryptBtn = document.getElementById('asymmetric-decrypt');
    const signBtn = document.getElementById('asymmetric-sign');
    const verifyBtn = document.getElementById('asymmetric-verify');
    const clearBtn = document.getElementById('asymmetric-clear');

    generateKeypairBtn.addEventListener('click', async () => {
        try {
            const algorithm = document.getElementById('asymmetric-algo').value;
            const keypair = await generateAsymmetricKeypair(algorithm);
            
            document.getElementById('public-key').value = keypair.publicKey;
            document.getElementById('private-key').value = keypair.privateKey;
            
            showMessage('Key pair generated successfully', 'success');
        } catch (error) {
            showMessage('Key generation failed: ' + error.message, 'error');
        }
    });

    encryptBtn.addEventListener('click', () => {
        showMessage('Asymmetric encryption implementation in progress', 'warning');
    });

    decryptBtn.addEventListener('click', () => {
        showMessage('Asymmetric decryption implementation in progress', 'warning');
    });

    signBtn.addEventListener('click', () => {
        showMessage('Digital signature implementation in progress', 'warning');
    });

    verifyBtn.addEventListener('click', () => {
        showMessage('Signature verification implementation in progress', 'warning');
    });

    clearBtn.addEventListener('click', () => {
        document.getElementById('asymmetric-input').value = '';
        document.getElementById('asymmetric-output').value = '';
        document.getElementById('public-key').value = '';
        document.getElementById('private-key').value = '';
        showMessage('Fields cleared', 'success');
    });
}

async function generateAsymmetricKeypair(algorithm) {
    switch (algorithm) {
        case 'rsa':
            return await generateRSAKeypair();
        default:
            throw new Error(`Algorithm ${algorithm} not yet implemented`);
    }
}

async function generateRSAKeypair() {
    const keypair = await window.crypto.subtle.generateKey(
        {
            name: 'RSA-OAEP',
            modulusLength: 2048,
            publicExponent: new Uint8Array([1, 0, 1]),
            hash: 'SHA-256'
        },
        true,
        ['encrypt', 'decrypt']
    );

    const publicKey = await window.crypto.subtle.exportKey('spki', keypair.publicKey);
    const privateKey = await window.crypto.subtle.exportKey('pkcs8', keypair.privateKey);

    return {
        publicKey: btoa(String.fromCharCode(...new Uint8Array(publicKey))),
        privateKey: btoa(String.fromCharCode(...new Uint8Array(privateKey)))
    };
}

// Hash Functions
function initializeHashFunctions() {
    const computeBtn = document.getElementById('hash-compute');
    const clearBtn = document.getElementById('hash-clear');

    computeBtn.addEventListener('click', async () => {
        const algorithm = document.getElementById('hash-algo').value;
        const input = document.getElementById('hash-input').value;
        const output = document.getElementById('hash-output');

        if (!input) {
            showMessage('Please enter text to hash', 'error');
            return;
        }

        try {
            const hash = await computeHash(algorithm, input);
            output.value = hash;
            showMessage('Hash computed successfully', 'success');
        } catch (error) {
            showMessage('Hash computation failed: ' + error.message, 'error');
        }
    });

    clearBtn.addEventListener('click', () => {
        document.getElementById('hash-input').value = '';
        document.getElementById('hash-output').value = '';
        showMessage('Fields cleared', 'success');
    });
}

async function computeHash(algorithm, text) {
    const encoder = new TextEncoder();
    const data = encoder.encode(text);

    switch (algorithm) {
        case 'sha256':
            return await hashWithSubtleCrypto('SHA-256', data);
        case 'sha384':
            return await hashWithSubtleCrypto('SHA-384', data);
        case 'sha512':
            return await hashWithSubtleCrypto('SHA-512', data);
        case 'sha1':
            return await hashWithSubtleCrypto('SHA-1', data);
        case 'md5':
            return md5Hash(text);
        default:
            throw new Error(`Hash algorithm ${algorithm} not yet implemented`);
    }
}

async function hashWithSubtleCrypto(algorithm, data) {
    const hashBuffer = await window.crypto.subtle.digest(algorithm, data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(byte => byte.toString(16).padStart(2, '0')).join('');
}

// Simple MD5 implementation
function md5Hash(text) {
    // This is a simplified implementation for demonstration
    // In practice, you would use a proper MD5 library
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
        hash = ((hash << 5) - hash + text.charCodeAt(i)) & 0xffffffff;
    }
    return Math.abs(hash).toString(16).padStart(8, '0');
}

// Classical Ciphers
function initializeClassicalCiphers() {
    const encryptBtn = document.getElementById('classical-encrypt');
    const decryptBtn = document.getElementById('classical-decrypt');
    const clearBtn = document.getElementById('classical-clear');

    encryptBtn.addEventListener('click', () => {
        const algorithm = document.getElementById('classical-algo').value;
        const key = document.getElementById('classical-key').value;
        const input = document.getElementById('classical-input').value;
        const output = document.getElementById('classical-output');

        if (!input) {
            showMessage('Please enter text to encrypt', 'error');
            return;
        }

        try {
            const encrypted = performClassicalEncryption(algorithm, input, key);
            output.value = encrypted;
            showMessage('Text encrypted successfully', 'success');
        } catch (error) {
            showMessage('Encryption failed: ' + error.message, 'error');
        }
    });

    decryptBtn.addEventListener('click', () => {
        const algorithm = document.getElementById('classical-algo').value;
        const key = document.getElementById('classical-key').value;
        const input = document.getElementById('classical-input').value;
        const output = document.getElementById('classical-output');

        if (!input) {
            showMessage('Please enter text to decrypt', 'error');
            return;
        }

        try {
            const decrypted = performClassicalDecryption(algorithm, input, key);
            output.value = decrypted;
            showMessage('Text decrypted successfully', 'success');
        } catch (error) {
            showMessage('Decryption failed: ' + error.message, 'error');
        }
    });

    clearBtn.addEventListener('click', () => {
        document.getElementById('classical-input').value = '';
        document.getElementById('classical-output').value = '';
        showMessage('Fields cleared', 'success');
    });
}

function performClassicalEncryption(algorithm, text, key) {
    switch (algorithm) {
        case 'caesar':
            return caesarCipher(text, parseInt(key) || 3, true);
        case 'atbash':
            return atbashCipher(text);
        case 'vigenere':
            return vigenereCipher(text, key || 'KEY', true);
        case 'playfair':
            return playfairCipher(text, key || 'KEYWORD', true);
        default:
            throw new Error(`Classical cipher ${algorithm} not yet implemented`);
    }
}

function performClassicalDecryption(algorithm, text, key) {
    switch (algorithm) {
        case 'caesar':
            return caesarCipher(text, parseInt(key) || 3, false);
        case 'atbash':
            return atbashCipher(text); // Atbash is symmetric
        case 'vigenere':
            return vigenereCipher(text, key || 'KEY', false);
        case 'playfair':
            return playfairCipher(text, key || 'KEYWORD', false);
        default:
            throw new Error(`Classical cipher ${algorithm} not yet implemented`);
    }
}

function caesarCipher(text, shift, encrypt = true) {
    if (!encrypt) shift = -shift;
    
    return text.replace(/[a-zA-Z]/g, function(char) {
        const start = char <= 'Z' ? 65 : 97;
        return String.fromCharCode(((char.charCodeAt(0) - start + shift + 26) % 26) + start);
    });
}

function atbashCipher(text) {
    return text.replace(/[a-zA-Z]/g, function(char) {
        if (char <= 'Z') {
            return String.fromCharCode(90 - (char.charCodeAt(0) - 65));
        } else {
            return String.fromCharCode(122 - (char.charCodeAt(0) - 97));
        }
    });
}

function vigenereCipher(text, key, encrypt = true) {
    key = key.toUpperCase();
    let result = '';
    let keyIndex = 0;
    
    for (let i = 0; i < text.length; i++) {
        const char = text[i];
        
        if (/[a-zA-Z]/.test(char)) {
            const isUpperCase = char === char.toUpperCase();
            const charCode = char.toUpperCase().charCodeAt(0) - 65;
            const keyChar = key[keyIndex % key.length].charCodeAt(0) - 65;
            
            let newCharCode;
            if (encrypt) {
                newCharCode = (charCode + keyChar) % 26;
            } else {
                newCharCode = (charCode - keyChar + 26) % 26;
            }
            
            const newChar = String.fromCharCode(newCharCode + 65);
            result += isUpperCase ? newChar : newChar.toLowerCase();
            keyIndex++;
        } else {
            result += char;
        }
    }
    
    return result;
}

function playfairCipher(text, key, encrypt = true) {
    // Simplified Playfair implementation
    const alphabet = 'ABCDEFGHIKLMNOPQRSTUVWXYZ'; // J is omitted
    key = key.toUpperCase().replace(/J/g, 'I');
    
    // Remove duplicates from key
    const uniqueKey = [...new Set(key)].join('');
    
    // Create cipher alphabet
    const cipherAlphabet = uniqueKey + alphabet.split('').filter(char => !uniqueKey.includes(char)).join('');
    
    // Simple substitution using the cipher alphabet
    return text.toUpperCase().replace(/[A-Z]/g, char => {
        if (char === 'J') char = 'I';
        const index = alphabet.indexOf(char);
        if (index === -1) return char;
        
        if (encrypt) {
            return cipherAlphabet[index];
        } else {
            return alphabet[cipherAlphabet.indexOf(char)];
        }
    });
}

// Encoding Utilities
function initializeEncodingUtilities() {
    const encodeBtn = document.getElementById('encoding-encode');
    const decodeBtn = document.getElementById('encoding-decode');
    const clearBtn = document.getElementById('encoding-clear');

    encodeBtn.addEventListener('click', () => {
        const type = document.getElementById('encoding-type').value;
        const input = document.getElementById('encoding-input').value;
        const output = document.getElementById('encoding-output');

        if (!input) {
            showMessage('Please enter text to encode', 'error');
            return;
        }

        try {
            const encoded = performEncoding(type, input);
            output.value = encoded;
            showMessage('Text encoded successfully', 'success');
        } catch (error) {
            showMessage('Encoding failed: ' + error.message, 'error');
        }
    });

    decodeBtn.addEventListener('click', () => {
        const type = document.getElementById('encoding-type').value;
        const input = document.getElementById('encoding-input').value;
        const output = document.getElementById('encoding-output');

        if (!input) {
            showMessage('Please enter text to decode', 'error');
            return;
        }

        try {
            const decoded = performDecoding(type, input);
            output.value = decoded;
            showMessage('Text decoded successfully', 'success');
        } catch (error) {
            showMessage('Decoding failed: ' + error.message, 'error');
        }
    });

    clearBtn.addEventListener('click', () => {
        document.getElementById('encoding-input').value = '';
        document.getElementById('encoding-output').value = '';
        showMessage('Fields cleared', 'success');
    });
}

function performEncoding(type, text) {
    switch (type) {
        case 'base64':
            return btoa(text);
        case 'morse':
            return textToMorse(text);
        case 'binary':
            return textToBinary(text);
        case 'ascii':
            return textToAscii(text);
        case 'base32':
            return base32Encode(text);
        default:
            throw new Error(`Encoding type ${type} not yet implemented`);
    }
}

function performDecoding(type, text) {
    switch (type) {
        case 'base64':
            return atob(text);
        case 'morse':
            return morseToText(text);
        case 'binary':
            return binaryToText(text);
        case 'ascii':
            return asciiToText(text);
        case 'base32':
            return base32Decode(text);
        default:
            throw new Error(`Decoding type ${type} not yet implemented`);
    }
}

function textToMorse(text) {
    const morseCode = {
        'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.',
        'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
        'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
        'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
        'Y': '-.--', 'Z': '--..', '0': '-----', '1': '.----', '2': '..---',
        '3': '...--', '4': '....-', '5': '.....', '6': '-....', '7': '--...',
        '8': '---..', '9': '----.', ' ': '/'
    };
    
    return text.toUpperCase().split('').map(char => morseCode[char] || char).join(' ');
}

function morseToText(morse) {
    const morseCode = {
        '.-': 'A', '-...': 'B', '-.-.': 'C', '-..': 'D', '.': 'E', '..-.': 'F',
        '--.': 'G', '....': 'H', '..': 'I', '.---': 'J', '-.-': 'K', '.-..': 'L',
        '--': 'M', '-.': 'N', '---': 'O', '.--.': 'P', '--.-': 'Q', '.-.': 'R',
        '...': 'S', '-': 'T', '..-': 'U', '...-': 'V', '.--': 'W', '-..-': 'X',
        '-.--': 'Y', '--..': 'Z', '-----': '0', '.----': '1', '..---': '2',
        '...--': '3', '....-': '4', '.....': '5', '-....': '6', '--...': '7',
        '---..': '8', '----.': '9', '/': ' '
    };
    
    return morse.split(' ').map(code => morseCode[code] || code).join('');
}

function textToBinary(text) {
    return text.split('').map(char => 
        char.charCodeAt(0).toString(2).padStart(8, '0')
    ).join(' ');
}

function binaryToText(binary) {
    return binary.split(' ').map(bin => 
        String.fromCharCode(parseInt(bin, 2))
    ).join('');
}

function textToAscii(text) {
    return text.split('').map(char => char.charCodeAt(0)).join(' ');
}

function asciiToText(ascii) {
    return ascii.split(' ').map(code => 
        String.fromCharCode(parseInt(code))
    ).join('');
}

function base32Encode(text) {
    // Simplified Base32 implementation
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    let result = '';
    let bits = 0;
    let value = 0;
    
    for (let i = 0; i < text.length; i++) {
        value = (value << 8) | text.charCodeAt(i);
        bits += 8;
        
        while (bits >= 5) {
            result += alphabet[(value >>> (bits - 5)) & 31];
            bits -= 5;
        }
    }
    
    if (bits > 0) {
        result += alphabet[(value << (5 - bits)) & 31];
    }
    
    return result;
}

function base32Decode(text) {
    // Simplified Base32 decoding
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    let result = '';
    let bits = 0;
    let value = 0;
    
    for (let i = 0; i < text.length; i++) {
        const char = text[i];
        const index = alphabet.indexOf(char);
        if (index === -1) continue;
        
        value = (value << 5) | index;
        bits += 5;
        
        if (bits >= 8) {
            result += String.fromCharCode((value >>> (bits - 8)) & 255);
            bits -= 8;
        }
    }
    
    return result;
}

// JSON Utilities
function initializeJSONUtilities() {
    const createBtn = document.getElementById('jwt-create');
    const decodeBtn = document.getElementById('jwt-decode');
    const verifyBtn = document.getElementById('jwt-verify');
    const clearBtn = document.getElementById('json-clear');

    createBtn.addEventListener('click', () => {
        try {
            const header = document.getElementById('jwt-header').value || '{"alg": "HS256", "typ": "JWT"}';
            const payload = document.getElementById('jwt-payload').value || '{}';
            const secret = document.getElementById('jwt-secret').value || 'secret';
            
            const jwt = createJWT(header, payload, secret);
            document.getElementById('json-output').value = jwt;
            showMessage('JWT created successfully', 'success');
        } catch (error) {
            showMessage('JWT creation failed: ' + error.message, 'error');
        }
    });

    decodeBtn.addEventListener('click', () => {
        try {
            const jwt = document.getElementById('json-input').value;
            const decoded = decodeJWT(jwt);
            document.getElementById('json-output').value = JSON.stringify(decoded, null, 2);
            showMessage('JWT decoded successfully', 'success');
        } catch (error) {
            showMessage('JWT decoding failed: ' + error.message, 'error');
        }
    });

    verifyBtn.addEventListener('click', () => {
        try {
            const jwt = document.getElementById('json-input').value;
            const secret = document.getElementById('jwt-secret').value || 'secret';
            const isValid = verifyJWT(jwt, secret);
            
            const status = isValid ? 'valid' : 'invalid';
            document.getElementById('json-output').value = `JWT is ${status}`;
            showMessage(`JWT is ${status}`, isValid ? 'success' : 'error');
        } catch (error) {
            showMessage('JWT verification failed: ' + error.message, 'error');
        }
    });

    clearBtn.addEventListener('click', () => {
        document.getElementById('json-input').value = '';
        document.getElementById('json-output').value = '';
        document.getElementById('jwt-header').value = '';
        document.getElementById('jwt-payload').value = '';
        showMessage('Fields cleared', 'success');
    });
}

function createJWT(header, payload, secret) {
    const encodedHeader = btoa(header).replace(/[=]/g, '');
    const encodedPayload = btoa(payload).replace(/[=]/g, '');
    
    const signature = btoa(`${encodedHeader}.${encodedPayload}.${secret}`).replace(/[=]/g, '');
    
    return `${encodedHeader}.${encodedPayload}.${signature}`;
}

function decodeJWT(jwt) {
    const parts = jwt.split('.');
    if (parts.length !== 3) {
        throw new Error('Invalid JWT format');
    }
    
    try {
        const header = JSON.parse(atob(parts[0]));
        const payload = JSON.parse(atob(parts[1]));
        
        return {
            header,
            payload,
            signature: parts[2]
        };
    } catch (error) {
        throw new Error('Invalid JWT encoding');
    }
}

function verifyJWT(jwt, secret) {
    try {
        const parts = jwt.split('.');
        if (parts.length !== 3) return false;
        
        const expectedSignature = btoa(`${parts[0]}.${parts[1]}.${secret}`).replace(/[=]/g, '');
        return parts[2] === expectedSignature;
    } catch (error) {
        return false;
    }
}